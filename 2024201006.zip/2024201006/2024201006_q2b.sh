#!/bin/bash
echo `expr $A + $B`

