#!/bin/bash
location=$(find / -iname $1 2>/dev/null)
head -n 4 $location
