QUESTION 1:
	- Provide permission to the file to be executed
	- Pass the file_name in command line argument
	- To execute, use command "./2024201006_q1.sh <file_name>"
	- It return the first 4 lines of the file.
	
QUESTION 2:
	PART A:
		- Provide permission to the file to be executed
		- Pass a number in command line argument to print how much number from the series to be printed.
		- To execute, use command "./2024201006_q2a.sh <number>"
	
	PART B:
		- Provide prmission to the file to be executed.
		- Export the two environment variable manually in the shell.
		- To export, use the command "export A=<value>" and "export B=<value>"
		- To execute, use command "./2024201006_q2b.sh"
		
