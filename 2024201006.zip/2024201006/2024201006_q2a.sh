
a=0
b=1
if [[ $1 -le 0 ]];
then
echo "input less than 0"

else
for i in $(seq 1 $1)
do
echo $a;
temp=$b
let "b=a+b"
let "a=temp";
done

fi
